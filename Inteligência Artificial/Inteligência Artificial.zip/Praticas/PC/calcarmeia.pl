accao(calcarSapato(Pe),[meia(Pe)],[sapato(Pe)],[]).
accao(calcarMeia(Pe),[],[meia(Pe)],[]).

estado_inicial( []).

estado_final( [sapato(esq),sapato(dir)]).
