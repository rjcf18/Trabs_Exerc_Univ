estado_inicial(((0,0), [[L,C],[],[],[]], [esq(L, C)])).

estado_final((_, _, [esq(C, L)])).


